import os
import json
from datetime import datetime, time
import pytz
from dotenv import load_dotenv

from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    ContextTypes, filters
)

load_dotenv()

TOKEN        = os.environ["BOT_TOKEN"]
ADMIN_ID     = int(os.environ["ADMIN_ID"])
ISH_BOSHLASH = time(9, 0)
KECH_CHEGARA = 15
TIMEZONE     = pytz.timezone("Asia/Tashkent")
DATA_FILE    = "attendance.json"

# Xodimlar @username : ism
# Har bir xodimning Telegram @username ni yozing (@ belgisisiz)
XODIMLAR = {
    "username_pm":     "PM",
    "username_smm1":   "SMM Manager 1",
    "username_smm2":   "SMM Manager 2",
    "username_ops":    "Operator",
    "username_dizayn": "Dizayner",
}

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def hozir():
    return datetime.now(TIMEZONE)

def bugun():
    return hozir().strftime("%Y-%m-%d")

def vaqt_str(iso):
    try:
        return datetime.fromisoformat(iso).strftime("%H:%M")
    except:
        return "—"

def xodim_ismi(u):
    return XODIMLAR.get(u, u or "Noma'lum")

def admin_kb():
    return ReplyKeyboardMarkup(
        [[KeyboardButton("📊 Bugungi hisobot"), KeyboardButton("📋 Haftalik hisobot")]],
        resize_keyboard=True
    )

def xodim_kb():
    return ReplyKeyboardMarkup(
        [[KeyboardButton("✅ Keldim"), KeyboardButton("🚪 Ketdim")]],
        resize_keyboard=True
    )

async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    username = update.effective_user.username or ""
    if uid == ADMIN_ID:
        await update.message.reply_text(
            "👑 Admin paneliga xush kelibsiz!\n\n"
            "📊 Bugungi hisobot — bugun kim keldi/ketdi\n"
            "📋 Haftalik hisobot — oxirgi 7 kun",
            reply_markup=admin_kb()
        )
    elif username in XODIMLAR:
        await update.message.reply_text(
            f"👋 Salom, {xodim_ismi(username)}!\n\n"
            "✅ Keldim — ishga kelganingizda bosing\n"
            "🚪 Ketdim — ketayotganda bosing",
            reply_markup=xodim_kb()
        )
    else:
        await update.message.reply_text(
            "⛔ Siz tizimda ro'yxatdan o'tmagansiz.\n"
            "Adminizga murojaat qiling."
        )

async def keldi_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    username = update.effective_user.username or ""
    if username not in XODIMLAR:
        await update.message.reply_text("⛔ Siz ro'yxatda yo'qsiz.")
        return

    data = load_data()
    sana = bugun()
    ism  = xodim_ismi(username)
    now  = hozir()

    data.setdefault(sana, {}).setdefault(username, {"ism": ism})

    if data[sana][username].get("keldi"):
        await update.message.reply_text(
            f"ℹ️ Siz bugun allaqachon belgilagansiz — {vaqt_str(data[sana][username]['keldi'])}"
        )
        return

    data[sana][username]["keldi"] = now.isoformat()
    save_data(data)

    ish_start = TIMEZONE.localize(datetime.combine(now.date(), ISH_BOSHLASH))
    kechikish = int((now - ish_start).total_seconds() / 60)

    if kechikish > KECH_CHEGARA:
        await ctx.bot.send_message(
            chat_id=ADMIN_ID,
            text=f"⚠️ Kech qoldi!\n👤 {ism}\n🕐 Keldi: {now.strftime('%H:%M')}\n⏱ Kechikish: {kechikish} daqiqa"
        )
        await update.message.reply_text(
            f"✅ Qayd etildi — {now.strftime('%H:%M')}\n⚠️ {kechikish} daqiqa kech qoldingiz."
        )
    else:
        await update.message.reply_text(
            f"✅ Yaxshi, {ism}!\nKelgan vaqt: {now.strftime('%H:%M')} 👍"
        )

async def ketdi_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    username = update.effective_user.username or ""
    if username not in XODIMLAR:
        await update.message.reply_text("⛔ Siz ro'yxatda yo'qsiz.")
        return

    data = load_data()
    sana = bugun()
    ism  = xodim_ismi(username)
    now  = hozir()

    info = data.get(sana, {}).get(username, {})
    if not info.get("keldi"):
        await update.message.reply_text("⚠️ Avval ✅ Keldim ni bosing.")
        return
    if info.get("ketdi"):
        await update.message.reply_text("ℹ️ Siz allaqachon ketganingizni belgilagansiz.")
        return

    keldi_dt = datetime.fromisoformat(info["keldi"])
    data[sana][username]["ketdi"] = now.isoformat()
    save_data(data)

    mins = int((now - keldi_dt).total_seconds() / 60)
    soat, daqiqa = divmod(mins, 60)

    await update.message.reply_text(
        f"🚪 Xayr, {ism}!\nKetgan vaqt: {now.strftime('%H:%M')}\n"
        f"Bugungi ish vaqti: {soat} soat {daqiqa} daqiqa"
    )
    await ctx.bot.send_message(
        chat_id=ADMIN_ID,
        text=f"📤 Ketdi: {ism}\n🕐 {now.strftime('%H:%M')}\n⏱ Ish vaqti: {soat} soat {daqiqa} daqiqa"
    )

async def bugungi_hisobot(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    data     = load_data()
    sana     = bugun()
    kun_data = data.get(sana, {})
    ish_start = TIMEZONE.localize(datetime.combine(datetime.now(TIMEZONE).date(), ISH_BOSHLASH))

    matn = f"📊 Hisobot — {sana}\n{'─'*28}\n"
    kelgan, kelmagan = [], []

    for username, ism in XODIMLAR.items():
        info = kun_data.get(username, {})
        if info.get("keldi"):
            kech = int((datetime.fromisoformat(info["keldi"]) - ish_start).total_seconds() / 60)
            status = f"⚠️ +{kech} daq" if kech > KECH_CHEGARA else "✅"
            ketdi_str = vaqt_str(info["ketdi"]) if info.get("ketdi") else "hali ishda"
            kelgan.append(f"👤 {ism} {status}\n   {vaqt_str(info['keldi'])} → {ketdi_str}")
        else:
            kelmagan.append(f"❌ {ism}")

    if kelgan:
        matn += "\n".join(kelgan)
    if kelmagan:
        matn += "\n\n⛔ Kelmaganlar:\n" + "\n".join(kelmagan)
    if not kelgan and not kelmagan:
        matn += "Hali hech kim belgilamagan."

    await update.message.reply_text(matn, reply_markup=admin_kb())

async def haftalik_hisobot(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    data = load_data()
    if not data:
        await update.message.reply_text("📋 Hozircha ma'lumot yo'q.", reply_markup=admin_kb())
        return

    matn = "📋 Haftalik hisobot\n" + "─" * 28 + "\n"
    for sana in sorted(data.keys(), reverse=True)[:7]:
        matn += f"\n📅 {sana}\n"
        for username, ism in XODIMLAR.items():
            info = data[sana].get(username, {})
            if info.get("keldi"):
                matn += f"  ✅ {ism}: {vaqt_str(info['keldi'])} → {vaqt_str(info.get('ketdi',''))}\n"
            else:
                matn += f"  ❌ {ism}\n"

    await update.message.reply_text(matn, reply_markup=admin_kb())

async def kelmagan_tekshir(ctx: ContextTypes.DEFAULT_TYPE):
    data     = load_data()
    kun_data = data.get(bugun(), {})
    kelmagan = [ism for u, ism in XODIMLAR.items() if not kun_data.get(u, {}).get("keldi")]
    if kelmagan:
        await ctx.bot.send_message(
            chat_id=ADMIN_ID,
            text="⚠️ Soat 10:00 — hali kelmagan xodimlar:\n" +
                 "\n".join(f"❌ {ism}" for ism in kelmagan)
        )

async def router(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    matn = update.message.text or ""
    if matn == "✅ Keldim":           await keldi_handler(update, ctx)
    elif matn == "🚪 Ketdim":         await ketdi_handler(update, ctx)
    elif matn == "📊 Bugungi hisobot": await bugungi_hisobot(update, ctx)
    elif matn == "📋 Haftalik hisobot": await haftalik_hisobot(update, ctx)

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, router))
    app.job_queue.run_daily(kelmagan_tekshir, time=time(10, 0, tzinfo=TIMEZONE))
    print("✅ HR Bot ishga tushdi!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
